package de.unioldenburg.jade.scheduling;

import java.util.Set;

/**
 *
 * @author Christoph Küpker
 */
public class Execution {
    
    private Job job;
    private Product product;
    private Variation variation;
    private Set<Operation> operations;
}
