Intelligent Systems SoSe 2015
�bung 03
Armin Pistoor, Christoph K�pker
======
README
======
1. Quellcode liegt in Paketen im Verzeichnis /src
2. Ausf�hren des Programms ist (um Classpath-Probleme zu umgehen) am einfachsten durch die bereitgestellte Jar. Die Abh�ngigkeiten (jade.jar) sollten automatisch durch das Unterverzeichnis /lib aufgel�st werden:
	java -jar MauMau_Pistoor_Kuepker.jar
3. Es �ffnet sich keine GUI f�r JADE. Das MauMau Spiel startet automatisch sobald sich die 3 Spieler beim Kartengeber angemeldet haben. Der Verlauf des Spiels kann der Konsole entnommen werden.